package com.example.mizanitk1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.*

// ------------------ DATA MODELS ------------------
data class Transaction(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Double
)

// ------------------ VIEWMODEL ------------------
class FinanceViewModel : ViewModel() {
    var balance by mutableDoubleStateOf(0.0)
        private set
    var transactions = mutableStateListOf<Transaction>()
        private set

    var savingsTarget by mutableDoubleStateOf(5000.0)
    var savingsCurrent by mutableDoubleStateOf(0.0)

    var darkMode by mutableStateOf(false)

    fun addTransaction(title: String, amount: Double) {
        transactions.add(0, Transaction(title = title, amount = amount))
        balance += amount
    }

    fun addToSavings(amount: Double) {
        if (balance >= amount) {
            savingsCurrent += amount
            balance -= amount
        }
    }

    fun resetData() {
        balance = 0.0
        transactions.clear()
        savingsCurrent = 0.0
    }
}

// ------------------ MAIN ACTIVITY ------------------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: FinanceViewModel = viewModel()
            MaterialTheme(colorScheme = if (vm.darkMode) darkColorScheme() else lightColorScheme()) {
                FinanceApp(vm)
            }
        }
    }
}

// ------------------ APP ROOT ------------------
@Composable
fun FinanceApp(viewModel: FinanceViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.GridView, null) },
                    label = { Text("Services") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Settings, null) },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                0 -> DashboardScreen(viewModel)
                1 -> ServicesScreen(viewModel)
                2 -> SettingsScreen(viewModel)
            }
        }
    }
}

// ------------------ DASHBOARD ------------------
@Composable
fun DashboardScreen(viewModel: FinanceViewModel) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { BalanceCard(viewModel.balance) }

        item {
            AddTransactionCard(
                title = title,
                amount = amount,
                onTitleChange = { title = it },
                onAmountChange = { amount = it },
                onAdd = {
                    amount.toDoubleOrNull()?.let {
                        viewModel.addTransaction(title, it)
                        title = ""
                        amount = ""
                    }
                }
            )
        }

        items(viewModel.transactions) {
            TransactionRow(it)
        }
    }
}

@Composable
fun BalanceCard(balance: Double) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF26A69A), Color(0xFF1E88E5))
                ),
                shape = RoundedCornerShape(20.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Current Balance", color = Color.White)
            Text(String.format(Locale.US, "$%.2f", balance),
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White)
        }
    }
}

@Composable
fun AddTransactionCard(
    title: String,
    amount: String,
    onTitleChange: (String) -> Unit,
    onAmountChange: (String) -> Unit,
    onAdd: () -> Unit
) {
    Card {
        Column(modifier = Modifier.padding(16.dp)) {
            OutlinedTextField(value = title, onValueChange = onTitleChange, label = { Text("Title") })
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = amount,
                onValueChange = onAmountChange,
                label = { Text("Amount (negative = expense)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onAdd) { Text("Add Transaction") }
        }
    }
}

@Composable
fun TransactionRow(tx: Transaction) {
    Card {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(tx.title)
            Text(String.format(Locale.US, "$%.2f", tx.amount),
                color = if (tx.amount < 0) Color.Red else Color.Green)
        }
    }
}

// ------------------ SERVICES ------------------
@Composable
fun ServicesScreen(viewModel: FinanceViewModel) {
    var savingsInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Savings Goal", fontWeight = FontWeight.Bold)
        LinearProgressIndicator(
            progress = { (viewModel.savingsCurrent / viewModel.savingsTarget).toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Text("$${viewModel.savingsCurrent} / $${viewModel.savingsTarget}")

        OutlinedTextField(
            value = savingsInput,
            onValueChange = { savingsInput = it },
            label = { Text("Add to savings") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Button(onClick = {
            savingsInput.toDoubleOrNull()?.let {
                viewModel.addToSavings(it)
                savingsInput = ""
            }
        }) { Text("Save") }
    }
}

// ------------------ SETTINGS ------------------
@Composable
fun SettingsScreen(viewModel: FinanceViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dark Mode")
            Spacer(modifier = Modifier.weight(1f))
            Switch(checked = viewModel.darkMode, onCheckedChange = { viewModel.darkMode = it })
        }
        Button(onClick = { viewModel.resetData() }, colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) {
            Text("Reset App Data", color = Color.White)
        }
    }
}
